/**
 * Customer feedback is stored as a genuine submission and remains non-public
 * until a project administrator chooses to approve it. No seeded feedback,
 * calculated rating, or invented testimonial is ever provided by this module.
 */
export const CUSTOMER_FEEDBACK_STATUSES = ["PENDING", "APPROVED", "REJECTED"] as const;
export type CustomerFeedbackStatus = (typeof CUSTOMER_FEEDBACK_STATUSES)[number];

export const CUSTOMER_RATINGS = [1, 2, 3, 4, 5] as const;

export function ratingLabel(rating: number) {
  if (rating === 5) return "Excellent";
  if (rating === 4) return "Very good";
  if (rating === 3) return "Good";
  if (rating === 2) return "Fair";
  return "Needs improvement";
}
