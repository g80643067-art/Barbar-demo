/**
 * Home Service domain contract: only pre-existing salon services and supplied
 * prices are exposed here. Travel fees, coverage, and final totals are never
 * calculated because they must be confirmed by the salon.
 */
export const HOME_SERVICE_STATUSES = [
  "PENDING",
  "ACCEPTED",
  "REJECTED",
  "RESCHEDULED",
  "COMPLETED",
] as const;

export type HomeServiceStatus = (typeof HOME_SERVICE_STATUSES)[number];

export const HOME_SERVICE_SERVICES = [
  { id: "haircut", name: "Haircut", category: "Haircut", basePrice: 50 },
  { id: "fashion-haircut", name: "Fashion Haircut", category: "Fashion Haircut", basePrice: 60 },
  { id: "shaving-denim", name: "Shaving — Denim", category: "Shaving", basePrice: 40 },
  { id: "shaving-dettol", name: "Shaving — Dettol", category: "Shaving", basePrice: 40 },
  { id: "shaving-foam", name: "Shaving — Foam", category: "Shaving", basePrice: 50 },
  { id: "shaving-gillette", name: "Shaving — Gillette Foam", category: "Shaving", basePrice: 60 },
  { id: "massage-scrub", name: "Massage — Scrub", category: "Massage", basePrice: 80 },
  { id: "massage-rose", name: "Massage — Rose Massage", category: "Massage", basePrice: 150 },
  { id: "massage-papaya", name: "Massage — Papaya", category: "Massage", basePrice: 150 },
  { id: "massage-gold", name: "Massage — Gold", category: "Massage", basePrice: 200 },
  { id: "massage-diamond", name: "Massage — Diamond", category: "Massage", basePrice: 250 },
  { id: "facial-real-aroma", name: "Facial — Real Aroma Kit", category: "Facial", basePrice: 800 },
  { id: "facial-gold", name: "Facial — Gold Facial Kit", category: "Facial", basePrice: 1000 },
  { id: "facial-diamond", name: "Facial — Diamond Facial Kit", category: "Facial", basePrice: 1200 },
  { id: "facial-shahnaz", name: "Facial — Shahnaz Kit", category: "Facial", basePrice: 2500 },
] as const;

export type HomeServiceCatalogItem = (typeof HOME_SERVICE_SERVICES)[number];

export const HOME_SERVICE_PRICE_NOTICE = "Home service charges may apply. Final home-service price will be confirmed by the salon.";
export const HOME_SERVICE_AVAILABILITY_NOTICE = "Home service availability depends on your location.";

export function getHomeServiceById(id: string): HomeServiceCatalogItem | undefined {
  return HOME_SERVICE_SERVICES.find((service) => service.id === id);
}

export function formatHomeBookingId(year: number, sequence: number) {
  return `HOME-ASS-${year}-${String(sequence).padStart(3, "0")}`;
}
