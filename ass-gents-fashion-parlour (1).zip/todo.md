# Project TODO

- [x] Upgrade the existing salon site to full-stack booking support while preserving the Noir Atelier public experience
- [x] Add the persistent Home Service request schema, booking-ID generation, and server-side validation
- [x] Create public request operations and protected administrator request-management operations
- [x] Add a premium Home Service landing-page section and entry points in navigation, hero, services, and mobile quick actions
- [x] Build the address-required multi-step Home Service request flow and truthful confirmation state
- [x] Build the protected Home Service Requests dashboard with status, rescheduling, calling, and manual WhatsApp drafting
- [x] Add owner-alert fallback and accurate no-automatic-WhatsApp messaging
- [x] Test compile, unit coverage, migration, and public desktop/mobile UX; preserve the live dataset by leaving customer-request submission to the salon owner
- [x] Defer owner sign-in and private moderation lifecycle validation at the user's request; the public website, booking, and feedback routes remain directly accessible without administrator login
- [x] Define a genuine-customer rating and feedback data model with moderation status and no seeded reviews
- [x] Build the public customer rating and feedback submission experience
- [x] Build administrator moderation controls for authentic submitted feedback
- [x] Test public feedback rendering, database migration, unit coverage, mobile presentation, and the truthful empty state without fabricating reviews
- [x] Verify direct public access to the salon website, Home Service booking, and feedback submission without administrator login
