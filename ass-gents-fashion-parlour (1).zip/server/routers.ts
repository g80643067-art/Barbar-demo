import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { HOME_SERVICE_STATUSES, HOME_SERVICE_SERVICES, getHomeServiceById } from "@shared/homeService";
import { CUSTOMER_FEEDBACK_STATUSES } from "@shared/customerFeedback";
import {
  createCustomerFeedback,
  createHomeServiceRequest,
  getHomeServiceRequestById,
  listCustomerFeedback,
  listHomeServiceRequests,
  updateCustomerFeedback,
  updateHomeServiceRequest,
} from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { notifyOwner } from "./_core/notification";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";

const serviceIds = HOME_SERVICE_SERVICES.map((service) => service.id) as [string, ...string[]];

function indiaToday() {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts();
  const value = (type: Intl.DateTimeFormatPartTypes) => parts.find((part) => part.type === type)?.value ?? "";
  return `${value("year")}-${value("month")}-${value("day")}`;
}

const requestedDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((value) => value >= indiaToday(), "Please choose today or a future date.");
const requestedTime = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Please choose a valid preferred time.");
const bookingInput = z.object({
  serviceId: z.enum(serviceIds),
  requestedDate,
  requestedTime,
  customerName: z.string().trim().min(2).max(120),
  customerPhone: z.string().trim().regex(/^\+?[0-9 ()-]{10,24}$/, "Please enter a valid mobile number."),
  customerAddress: z.string().trim().min(15, "Please enter your complete home address.").max(1200),
  specialInstructions: z.string().trim().max(1200).optional(),
});

const feedbackInput = z.object({
  rating: z.number().int().min(1).max(5),
  customerName: z.string().trim().min(2, "Please enter your name.").max(120),
  serviceName: z.string().trim().max(120).optional(),
  message: z.string().trim().min(12, "Please share a little more detail.").max(2000),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  homeService: router({
    catalog: publicProcedure.query(() => HOME_SERVICE_SERVICES),
    createRequest: publicProcedure.input(bookingInput).mutation(async ({ input }) => {
      const service = getHomeServiceById(input.serviceId);
      if (!service) throw new TRPCError({ code: "BAD_REQUEST", message: "Please choose an available salon service." });

      const request = await createHomeServiceRequest({ ...input, service, customerPhone: input.customerPhone.replace(/[ ()-]/g, "") });
      const ownerAlertDelivered = await notifyOwner({
        title: "New Home Service request",
        content: `Booking ${request.bookingId}\nCustomer: ${request.customerName}\nService: ${request.serviceName} (₹${request.basePrice})\nRequested: ${request.requestedDate} at ${request.requestedTime}\nPhone: ${request.customerPhone}\nAddress: ${request.customerAddress}\nHome visit charge: To be confirmed`,
      }).catch(() => false);

      return { request, ownerAlertDelivered };
    }),
    admin: router({
      list: adminProcedure.input(z.object({ status: z.enum(HOME_SERVICE_STATUSES).optional() }).optional()).query(({ input }) => listHomeServiceRequests(input?.status)),
      get: adminProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => getHomeServiceRequestById(input.id)),
      update: adminProcedure.input(z.object({
        id: z.number().int().positive(),
        status: z.enum(HOME_SERVICE_STATUSES),
        rescheduledDate: requestedDate.optional(),
        rescheduledTime: requestedTime.optional(),
        adminNote: z.string().trim().max(1200).optional(),
      }).superRefine((value, context) => {
        if (value.status === "RESCHEDULED" && (!value.rescheduledDate || !value.rescheduledTime)) {
          context.addIssue({ code: "custom", message: "A rescheduled date and time are required." });
        }
      })).mutation(({ input }) => updateHomeServiceRequest(input.id, input)),
    }),
  }),
  feedback: router({
    publicList: publicProcedure.query(() => listCustomerFeedback("APPROVED")),
    submit: publicProcedure.input(feedbackInput).mutation(async ({ input }) => {
      const feedback = await createCustomerFeedback(input);
      const ownerAlertDelivered = await notifyOwner({
        title: "New customer feedback",
        content: `Customer: ${feedback.customerName}\nRating: ${feedback.rating}/5\nService: ${feedback.serviceName ?? "Not specified"}\nFeedback: ${feedback.message}\nStatus: Pending moderation`,
      }).catch(() => false);
      return { feedback, ownerAlertDelivered };
    }),
    admin: router({
      list: adminProcedure.input(z.object({ status: z.enum(CUSTOMER_FEEDBACK_STATUSES).optional() }).optional()).query(({ input }) => listCustomerFeedback(input?.status)),
      update: adminProcedure.input(z.object({
        id: z.number().int().positive(),
        status: z.enum(CUSTOMER_FEEDBACK_STATUSES),
        adminNote: z.string().trim().max(1200).optional(),
      })).mutation(({ input }) => updateCustomerFeedback(input.id, input)),
    }),
  }),
});

export type AppRouter = typeof appRouter;
