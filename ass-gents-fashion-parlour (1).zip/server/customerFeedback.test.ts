import { describe, expect, it } from "vitest";
import { CUSTOMER_FEEDBACK_STATUSES, CUSTOMER_RATINGS, ratingLabel } from "@shared/customerFeedback";

describe("customer feedback contract", () => {
  it("allows ratings from one through five only", () => {
    expect(CUSTOMER_RATINGS).toEqual([1, 2, 3, 4, 5]);
  });

  it("starts submissions in a moderation workflow", () => {
    expect(CUSTOMER_FEEDBACK_STATUSES).toEqual(["PENDING", "APPROVED", "REJECTED"]);
  });

  it("provides only rating labels and no fabricated customer content", () => {
    expect(ratingLabel(5)).toBe("Excellent");
    expect(ratingLabel(1)).toBe("Needs improvement");
  });
});
