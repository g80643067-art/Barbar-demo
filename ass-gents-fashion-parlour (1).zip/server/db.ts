import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { customerFeedback, homeServiceRequests, InsertUser, users } from "../drizzle/schema";
import { type CustomerFeedbackStatus } from "@shared/customerFeedback";
import { formatHomeBookingId, type HomeServiceCatalogItem, type HomeServiceStatus } from "@shared/homeService";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach((field) => {
    const value = user[field];
    if (value === undefined) return;
    values[field] = value ?? null;
    updateSet[field] = value ?? null;
  });
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export type CreateHomeServiceRequestInput = {
  service: HomeServiceCatalogItem;
  requestedDate: string;
  requestedTime: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  specialInstructions?: string;
};

export async function createHomeServiceRequest(input: CreateHomeServiceRequestInput) {
  const db = await getDb();
  if (!db) throw new Error("Booking service is temporarily unavailable. Please call the salon.");

  const result = await db.insert(homeServiceRequests).values({
    bookingId: null,
    serviceId: input.service.id,
    serviceName: input.service.name,
    serviceCategory: input.service.category,
    basePrice: input.service.basePrice,
    requestedDate: input.requestedDate,
    requestedTime: input.requestedTime,
    customerName: input.customerName,
    customerPhone: input.customerPhone,
    customerAddress: input.customerAddress,
    specialInstructions: input.specialInstructions?.trim() || null,
  });
  const requestId = Number(result[0].insertId);
  const bookingId = formatHomeBookingId(new Date().getUTCFullYear(), requestId);
  await db.update(homeServiceRequests).set({ bookingId }).where(eq(homeServiceRequests.id, requestId));
  const request = await getHomeServiceRequestById(requestId);
  if (!request) throw new Error("Booking was created but could not be retrieved.");
  return request;
}

export async function getHomeServiceRequestById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Booking service is temporarily unavailable.");
  const result = await db.select().from(homeServiceRequests).where(eq(homeServiceRequests.id, id)).limit(1);
  return result[0];
}

export async function listHomeServiceRequests(status?: HomeServiceStatus) {
  const db = await getDb();
  if (!db) throw new Error("Booking service is temporarily unavailable.");
  if (status) return db.select().from(homeServiceRequests).where(eq(homeServiceRequests.status, status)).orderBy(desc(homeServiceRequests.createdAt));
  return db.select().from(homeServiceRequests).orderBy(desc(homeServiceRequests.createdAt));
}

export async function updateHomeServiceRequest(
  id: number,
  update: { status: HomeServiceStatus; rescheduledDate?: string; rescheduledTime?: string; adminNote?: string },
) {
  const db = await getDb();
  if (!db) throw new Error("Booking service is temporarily unavailable.");
  await db.update(homeServiceRequests).set({
    status: update.status,
    rescheduledDate: update.rescheduledDate ?? null,
    rescheduledTime: update.rescheduledTime ?? null,
    adminNote: update.adminNote?.trim() || null,
  }).where(eq(homeServiceRequests.id, id));
  const request = await getHomeServiceRequestById(id);
  if (!request) throw new Error("Home Service request was not found.");
  return request;
}

export type CreateCustomerFeedbackInput = {
  rating: number;
  customerName: string;
  serviceName?: string;
  message: string;
};

export async function createCustomerFeedback(input: CreateCustomerFeedbackInput) {
  const db = await getDb();
  if (!db) throw new Error("Feedback is temporarily unavailable. Please call the salon.");
  const result = await db.insert(customerFeedback).values({
    rating: input.rating,
    customerName: input.customerName.trim(),
    serviceName: input.serviceName?.trim() || null,
    message: input.message.trim(),
  });
  const feedbackId = Number(result[0].insertId);
  const feedback = await getCustomerFeedbackById(feedbackId);
  if (!feedback) throw new Error("Feedback was received but could not be retrieved.");
  return feedback;
}

export async function getCustomerFeedbackById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Feedback is temporarily unavailable.");
  const result = await db.select().from(customerFeedback).where(eq(customerFeedback.id, id)).limit(1);
  return result[0];
}

export async function listCustomerFeedback(status?: CustomerFeedbackStatus) {
  const db = await getDb();
  if (!db) throw new Error("Feedback is temporarily unavailable.");
  if (status) return db.select().from(customerFeedback).where(eq(customerFeedback.status, status)).orderBy(desc(customerFeedback.createdAt));
  return db.select().from(customerFeedback).orderBy(desc(customerFeedback.createdAt));
}

export async function updateCustomerFeedback(
  id: number,
  update: { status: CustomerFeedbackStatus; adminNote?: string },
) {
  const db = await getDb();
  if (!db) throw new Error("Feedback is temporarily unavailable.");
  await db.update(customerFeedback).set({
    status: update.status,
    adminNote: update.adminNote?.trim() || null,
  }).where(eq(customerFeedback.id, id));
  const feedback = await getCustomerFeedbackById(id);
  if (!feedback) throw new Error("Customer feedback was not found.");
  return feedback;
}
