import { describe, expect, it } from "vitest";
import {
  HOME_SERVICE_AVAILABILITY_NOTICE,
  HOME_SERVICE_PRICE_NOTICE,
  HOME_SERVICE_SERVICES,
  formatHomeBookingId,
  getHomeServiceById,
} from "@shared/homeService";

describe("Home Service service contract", () => {
  it("uses only supplied salon services and preserves their exact base prices", () => {
    expect(getHomeServiceById("fashion-haircut")).toMatchObject({ name: "Fashion Haircut", basePrice: 60 });
    expect(getHomeServiceById("shaving-foam")).toMatchObject({ name: "Shaving — Foam", basePrice: 50 });
    expect(HOME_SERVICE_SERVICES.every((service) => service.basePrice > 0)).toBe(true);
  });

  it("creates the required human-readable booking identifier format", () => {
    expect(formatHomeBookingId(2026, 1)).toBe("HOME-ASS-2026-001");
    expect(formatHomeBookingId(2026, 1047)).toBe("HOME-ASS-2026-1047");
  });

  it("keeps home visit charges and location availability subject to salon confirmation", () => {
    expect(HOME_SERVICE_PRICE_NOTICE).toContain("charges may apply");
    expect(HOME_SERVICE_AVAILABILITY_NOTICE).toContain("depends on your location");
  });
});
