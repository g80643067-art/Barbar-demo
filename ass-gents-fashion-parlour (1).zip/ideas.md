# A.S.S Gents Fashion Parlour — Design Exploration

## Three Directional Approaches

### 1. Noir Atelier
**Very Brief Intro:** A cinematic, tactile grooming atelier built from charcoal, blackened steel, tobacco wood, and an antique-bronze accent. It makes the salon feel composed and editorial rather than theatrical.

**Probability:** 0.07

### 2. Sunlit Heritage
**Very Brief Intro:** A refined Indian barbershop interpretation with parchment whites, oxblood leather, handcrafted signage, and warm afternoon light. It would feel approachable and quietly established.

**Probability:** 0.04

### 3. Monochrome Precision
**Very Brief Intro:** A high-fashion, gallery-like grooming identity with stark monochrome photography, sculptural layouts, and minimal steel detailing. It would feel technical, crisp, and fashion-forward.

**Probability:** 0.09

## Chosen Direction — Noir Atelier

### Design Movement
**Cinematic editorial hospitality** fused with the material discipline of an understated luxury atelier. The intent is a premium grooming experience that is dark and immersive without resorting to neon, generic nightclub aesthetics, or ornate faux-luxury decoration.

### Core Principles

1. **Material credibility:** Blackened steel, smoked glass, dark tobacco wood, paper-like grain, and brushed-silver details should feel tactile rather than digitally glossy.
2. **Editorial restraint:** Large type, deliberate cropping, asymmetric compositions, and generous breathing space create confidence without over-explaining.
3. **Measured motion:** Scissors, light sweeps, and content reveals provide a thread of movement; all animation is controlled, brief, and secondary to readability.
4. **Direct utility:** The exact price list and phone access remain unambiguous, with high-contrast touch targets on mobile.

### Color Philosophy
The foundation is **Obsidian Charcoal** rather than pure black: it creates depth while allowing ink-like textures and photography to breathe. A single antique-bronze accent, **Cinder Bronze**, gives the UI warmth and links metallic tools to the visual identity. A quiet bone-white supplies editorial contrast for essential copy; muted slate supports secondary information. Gold is never used as a broad fill or decorative gradient.

### Layout Paradigm
The site is composed as a **cinematic promenade**: a tall entry experience leads into a sequence of offset editorial frames, narrow captions, overscaled copy, and varied visual blocks. Sections are not housed in a repeating central card grid. Service cards form an asymmetric scrollable rail and the price menu appears as a large typographic ledger.

### Signature Elements

1. A small **brushed-metal scissors emblem** acts as the brand’s visual punctuation, appearing at key section breaks and in the entry sequence.
2. A fine **Cinder Bronze rule** and small uppercase eyebrow labels create rhythm between highly photographic sections.
3. A gentle **film-grain veil** and restrained radial pools of warm light make empty space feel intentional.

### Interaction Philosophy
Interactions should mirror a groomer’s precision: buttons settle into place magnetically, service filters change content with a composed dissolve and lift, and image cards reveal their details with a controlled upward glide. Every important action is immediately legible and keyboard accessible.

### Animation
The opening uses a CSS-rendered metallic scissors motif—rather than a heavy 3D asset—for a quick cinematic reveal. Scissors rotate slightly, open and close once, and sweep into a metallic wipe. On scroll, imagery and content translate no more than 18px with opacity reveals. Card tilt is bounded and disabled for touch/reduced-motion users. All nonessential motion respects `prefers-reduced-motion`.

### Typography System
**DM Serif Display** carries headlines in a high-contrast editorial voice; **Manrope** handles labels, navigation, prices, and body copy with clear, contemporary utility. Headlines use slightly tight tracking and sculpted line breaks. Labels are uppercase with wider letter spacing. Prices are set in Manrope semibold so numerical information stays unmistakable.

### Brand Essence
**A.S.S Gents Fashion Parlour is a cinematic, accessible men’s grooming studio in Khutaha for clients who see a fresh cut as part of their identity.**

**Personality:** Precise, grounded, self-assured.

### Brand Voice
Headlines are declarative and spare. CTAs use active, practical verbs; microcopy is direct and never pretends the salon has credentials or amenities that are not supplied.

> “Your style. Your identity.”

> “Choose a service. Make the call.”

### Wordmark & Logo
The wordmark uses a compact two-line lockup: the initials **A.S.S** in a restrained serif above the full salon name in tracked sans-serif. The graphic mark is an angular, brushed-metal scissors silhouette with a subtle bronze pivot—an ownable icon that works without text.

### Signature Brand Color
**Cinder Bronze — #C89155**

## Style Decisions

- **Service presentation:** Services never appear as a uniform ecommerce-style grid; they are arranged as an editorial service edit with category rhythm, varied photographic crops, and clear prices.
- **Imagery:** Photography stays within warm noir atelier lighting—black chair, hands, tools, mirrors, tobacco wood, skin, and hair texture—with no repeated stock-like card pattern.
- **Brand mark:** The brushed-metal scissors emblem is recurring visual punctuation at major section breaks, and the A.S.S two-line wordmark is treated as a distinct salon signature.
- **Home Service booking:** Service selection follows an atelier price-ledger rhythm—category rules, strong prices, and individual typographic rows rather than an equal-card grid.
- **Utility materiality:** Booking surfaces use smoked-glass depth, quiet paper grain, blackened-steel dividers, and warm charcoal light so functional moments remain part of the cinematic story.
