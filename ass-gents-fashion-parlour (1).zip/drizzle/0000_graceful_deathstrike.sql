CREATE TABLE `home_service_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookingId` varchar(32),
	`status` enum('PENDING','ACCEPTED','REJECTED','RESCHEDULED','COMPLETED') NOT NULL DEFAULT 'PENDING',
	`serviceId` varchar(64) NOT NULL,
	`serviceName` varchar(120) NOT NULL,
	`serviceCategory` varchar(64) NOT NULL,
	`basePrice` int NOT NULL,
	`requestedDate` varchar(10) NOT NULL,
	`requestedTime` varchar(5) NOT NULL,
	`customerName` varchar(120) NOT NULL,
	`customerPhone` varchar(24) NOT NULL,
	`customerAddress` text NOT NULL,
	`specialInstructions` text,
	`rescheduledDate` varchar(10),
	`rescheduledTime` varchar(5),
	`adminNote` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `home_service_requests_id` PRIMARY KEY(`id`),
	CONSTRAINT `home_service_requests_booking_id_unique` UNIQUE(`bookingId`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
--> statement-breakpoint
CREATE INDEX `home_service_requests_status_created_at_index` ON `home_service_requests` (`status`,`createdAt`);