CREATE TABLE `customer_feedback` (
	`id` int AUTO_INCREMENT NOT NULL,
	`status` enum('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
	`rating` int NOT NULL,
	`customerName` varchar(120) NOT NULL,
	`serviceName` varchar(120),
	`message` text NOT NULL,
	`adminNote` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customer_feedback_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `customer_feedback_status_created_at_index` ON `customer_feedback` (`status`,`createdAt`);