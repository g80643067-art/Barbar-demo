import { index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";
import { HOME_SERVICE_STATUSES } from "@shared/homeService";
import { CUSTOMER_FEEDBACK_STATUSES } from "@shared/customerFeedback";

/** Core user table backing the Manus OAuth authentication flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

/**
 * A truthful, address-required request for at-home grooming. Base price is an
 * immutable snapshot of the existing salon price; travel cost and final total
 * intentionally remain absent until the salon manually confirms them.
 */
export const homeServiceRequests = mysqlTable(
  "home_service_requests",
  {
    id: int("id").autoincrement().primaryKey(),
    bookingId: varchar("bookingId", { length: 32 }),
    status: mysqlEnum("status", HOME_SERVICE_STATUSES).default("PENDING").notNull(),
    serviceId: varchar("serviceId", { length: 64 }).notNull(),
    serviceName: varchar("serviceName", { length: 120 }).notNull(),
    serviceCategory: varchar("serviceCategory", { length: 64 }).notNull(),
    basePrice: int("basePrice").notNull(),
    requestedDate: varchar("requestedDate", { length: 10 }).notNull(),
    requestedTime: varchar("requestedTime", { length: 5 }).notNull(),
    customerName: varchar("customerName", { length: 120 }).notNull(),
    customerPhone: varchar("customerPhone", { length: 24 }).notNull(),
    customerAddress: text("customerAddress").notNull(),
    specialInstructions: text("specialInstructions"),
    rescheduledDate: varchar("rescheduledDate", { length: 10 }),
    rescheduledTime: varchar("rescheduledTime", { length: 5 }),
    adminNote: text("adminNote"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    uniqueIndex("home_service_requests_booking_id_unique").on(table.bookingId),
    index("home_service_requests_status_created_at_index").on(table.status, table.createdAt),
  ],
);

/**
 * Genuine customer ratings and written feedback. Entries are private while
 * pending/rejected and only approved records may be surfaced on the public site.
 */
export const customerFeedback = mysqlTable(
  "customer_feedback",
  {
    id: int("id").autoincrement().primaryKey(),
    status: mysqlEnum("status", CUSTOMER_FEEDBACK_STATUSES).default("PENDING").notNull(),
    rating: int("rating").notNull(),
    customerName: varchar("customerName", { length: 120 }).notNull(),
    serviceName: varchar("serviceName", { length: 120 }),
    message: text("message").notNull(),
    adminNote: text("adminNote"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [index("customer_feedback_status_created_at_index").on(table.status, table.createdAt)],
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type HomeServiceRequest = typeof homeServiceRequests.$inferSelect;
export type CustomerFeedback = typeof customerFeedback.$inferSelect;
