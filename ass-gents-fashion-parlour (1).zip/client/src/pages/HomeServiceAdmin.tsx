/**
 * Noir Atelier admin workspace: protected Home Service request management using
 * the provided dashboard shell. It prepares manual call/WhatsApp follow-up and
 * never claims that a message has been automatically sent.
 */
import { CalendarClock, Check, ExternalLink, MessageCircle, Phone, RotateCcw, X } from "lucide-react";
import { useMemo, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { HOME_SERVICE_STATUSES, type HomeServiceStatus } from "@shared/homeService";

const statusTone: Record<HomeServiceStatus, string> = { PENDING: "pending", ACCEPTED: "accepted", REJECTED: "rejected", RESCHEDULED: "rescheduled", COMPLETED: "completed" };

function messageFor(request: { bookingId: string | null; customerName: string; serviceName: string; requestedDate: string; requestedTime: string; basePrice: number; customerAddress: string }) {
  return `NEW HOME SERVICE REQUEST\nA.S.S GENTS FASHION PARLOUR\nBooking ID: ${request.bookingId}\nCustomer: ${request.customerName}\nService: ${request.serviceName}\nDate: ${request.requestedDate}\nTime: ${request.requestedTime}\nAddress: ${request.customerAddress}\nService Price: ₹${request.basePrice}\nHome Visit Charge: To be confirmed`;
}

export default function HomeServiceAdmin() {
  return <DashboardLayout><HomeServiceAdminContent /></DashboardLayout>;
}

function HomeServiceAdminContent() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const [statusFilter, setStatusFilter] = useState<HomeServiceStatus | "ALL">("ALL");
  const requests = trpc.homeService.admin.list.useQuery(statusFilter === "ALL" ? undefined : { status: statusFilter });
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const selected = useMemo(() => requests.data?.find((request) => request.id === selectedId) ?? null, [requests.data, selectedId]);
  const [nextStatus, setNextStatus] = useState<HomeServiceStatus>("PENDING");
  const [rescheduleDate, setRescheduleDate] = useState("");
  const [rescheduleTime, setRescheduleTime] = useState("");
  const [adminNote, setAdminNote] = useState("");
  const updateRequest = trpc.homeService.admin.update.useMutation({ onSuccess: () => { utils.homeService.admin.list.invalidate(); setSelectedId(null); } });

  const openRequest = (id: number) => {
    const request = requests.data?.find((item) => item.id === id);
    setSelectedId(id);
    setNextStatus(request?.status ?? "PENDING");
    setRescheduleDate(request?.rescheduledDate ?? "");
    setRescheduleTime(request?.rescheduledTime ?? "");
    setAdminNote(request?.adminNote ?? "");
  };

  if (user && user.role !== "admin") return <section className="admin-guard"><span className="eyebrow">Restricted access</span><h1>ADMIN ACCESS REQUIRED.</h1><p>This workspace is available to the A.S.S project administrator only.</p></section>;

  return <section className="admin-home-service"><header className="admin-heading"><div><span className="eyebrow">A.S.S administration</span><h1>HOME SERVICE<br /><em>REQUESTS.</em></h1><p>Review each request, confirm details directly with the customer, and update the salon’s working status.</p></div><div className="admin-stat"><CalendarClock size={18} /><span>{requests.data?.length ?? 0}</span><small>requests shown</small></div></header><div className="admin-filters"><button className={statusFilter === "ALL" ? "active" : ""} onClick={() => setStatusFilter("ALL")}>All</button>{HOME_SERVICE_STATUSES.map((status) => <button className={statusFilter === status ? "active" : ""} onClick={() => setStatusFilter(status)} key={status}>{status}</button>)}</div><div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Booking</th><th>Customer</th><th>Service</th><th>Requested</th><th>Price</th><th>Status</th><th /></tr></thead><tbody>{requests.isLoading && <tr><td colSpan={7}>Loading Home Service requests…</td></tr>}{requests.data?.length === 0 && <tr><td colSpan={7}>No requests match this view yet.</td></tr>}{requests.data?.map((request) => <tr key={request.id}><td><b>{request.bookingId}</b><small>{new Date(request.createdAt).toLocaleString()}</small></td><td><b>{request.customerName}</b><small>{request.customerPhone}</small></td><td>{request.serviceName}</td><td>{request.requestedDate}<small>{request.requestedTime}</small></td><td>₹{request.basePrice}<small>Visit: TBD</small></td><td><span className={`status-pill ${statusTone[request.status]}`}>{request.status}</span></td><td><button className="admin-view" onClick={() => openRequest(request.id)}>View <ExternalLink size={13} /></button></td></tr>)}</tbody></table></div>{selected && <aside className="request-drawer"><div className="drawer-head"><div><span className="eyebrow">Request detail</span><h2>{selected.bookingId}</h2></div><button onClick={() => setSelectedId(null)} aria-label="Close request detail"><X /></button></div><div className="drawer-customer"><strong>{selected.customerName}</strong><span>{selected.serviceName} · ₹{selected.basePrice}</span></div><dl className="request-details"><div><dt>Requested date</dt><dd>{selected.requestedDate}</dd></div><div><dt>Preferred time</dt><dd>{selected.requestedTime}</dd></div><div><dt>Phone</dt><dd>{selected.customerPhone}</dd></div><div><dt>Address</dt><dd>{selected.customerAddress}</dd></div>{selected.specialInstructions && <div><dt>Instructions</dt><dd>{selected.specialInstructions}</dd></div>}</dl><div className="drawer-actions"><a href={`tel:${selected.customerPhone.replace(/[^+\d]/g, "")}`}><Phone size={14} /> Call customer</a><a href={`https://wa.me/${selected.customerPhone.replace(/\D/g, "")}?text=${encodeURIComponent(messageFor(selected))}`} target="_blank" rel="noreferrer"><MessageCircle size={14} /> Prepare WhatsApp</a></div><p className="drawer-note">The WhatsApp action opens a prefilled draft for manual review. It does not send a message automatically.</p><div className="admin-update"><label>Status<select value={nextStatus} onChange={(event) => setNextStatus(event.target.value as HomeServiceStatus)}>{HOME_SERVICE_STATUSES.map((status) => <option value={status} key={status}>{status}</option>)}</select></label>{nextStatus === "RESCHEDULED" && <div className="reschedule-fields"><label>New date<input type="date" value={rescheduleDate} onChange={(event) => setRescheduleDate(event.target.value)} /></label><label>New time<input type="time" value={rescheduleTime} onChange={(event) => setRescheduleTime(event.target.value)} /></label></div>}<label>Internal note<textarea value={adminNote} onChange={(event) => setAdminNote(event.target.value)} /></label>{updateRequest.error && <p className="admin-error">{updateRequest.error.message}</p>}<button className="admin-save" onClick={() => updateRequest.mutate({ id: selected.id, status: nextStatus, rescheduledDate: nextStatus === "RESCHEDULED" ? rescheduleDate : undefined, rescheduledTime: nextStatus === "RESCHEDULED" ? rescheduleTime : undefined, adminNote })} disabled={updateRequest.isPending}>{updateRequest.isPending ? "Saving…" : <><Check size={14} /> Save request</>}</button></div></aside>}</section>;
}
