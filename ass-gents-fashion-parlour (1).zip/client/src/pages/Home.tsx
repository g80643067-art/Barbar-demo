/**
 * Noir Atelier landing page: an asymmetric cinematic promenade built from
 * obsidian surfaces, editorial type, Cinder Bronze cues, and subtle scissors
 * motifs. No invented reviews, awards, claims, or business details appear.
 */
import { ArrowRight, CalendarDays, House, MapPin, Menu, MessageSquareHeart, Phone, Scissors, Send, Star, X } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";

type Category = "All" | "Shaving" | "Hair Cutting" | "Massage" | "Facial Kit" | "Bleach";

type Service = {
  name: string;
  category: Exclude<Category, "All">;
  price: string;
  description: string;
};

const PHONE = "+91 93059 68252";
const PHONE_LINK = "tel:+919305968252";
const DIRECTIONS = "https://www.google.com/maps/dir/?api=1&destination=Khutaha%2CGhorawal%2CSonbhadra%2CUttar+Pradesh%2CIndia";

const services: Service[] = [
  { name: "Denim", category: "Shaving", price: "₹40", description: "A clean, traditional barber shave." },
  { name: "Dettol", category: "Shaving", price: "₹40", description: "A careful, fresh shaving service." },
  { name: "Foam", category: "Shaving", price: "₹50", description: "Rich foam application with a close finish." },
  { name: "Gillette Foam", category: "Shaving", price: "₹60", description: "A precise shave with professional foam." },
  { name: "Round Hair", category: "Hair Cutting", price: "₹30", description: "A neat, classic round hair cut." },
  { name: "Children's Haircut", category: "Hair Cutting", price: "₹40", description: "A comfortable haircut for children." },
  { name: "Haircut", category: "Hair Cutting", price: "₹50", description: "A clean professional men’s haircut." },
  { name: "Fashion Haircut", category: "Hair Cutting", price: "₹60", description: "A sharper, style-focused haircut." },
  { name: "Scrub", category: "Massage", price: "₹80", description: "A focused facial scrub treatment." },
  { name: "Rose Massage", category: "Massage", price: "₹150", description: "A relaxing rose-inspired facial massage." },
  { name: "Papaya", category: "Massage", price: "₹150", description: "A refreshing papaya facial treatment." },
  { name: "Gold Massage", category: "Massage", price: "₹200", description: "A premium gold facial massage." },
  { name: "Diamond Massage", category: "Massage", price: "₹250", description: "An ultra-premium diamond facial massage." },
  { name: "Real Aroma Kit", category: "Facial Kit", price: "₹800", description: "A professional aroma facial treatment." },
  { name: "Gold Facial Kit", category: "Facial Kit", price: "₹1,000", description: "A premium gold facial-kit treatment." },
  { name: "Diamond Facial Kit", category: "Facial Kit", price: "₹1,200", description: "A refined diamond facial-kit treatment." },
  { name: "Shahnaz Kit", category: "Facial Kit", price: "₹2,500", description: "A complete professional facial-kit service." },
  { name: "Charcoal Mask", category: "Bleach", price: "₹150", description: "A professional charcoal mask treatment." },
  { name: "Olivia", category: "Bleach", price: "₹150", description: "A premium skincare and bleach treatment." },
  { name: "Oxy Life", category: "Bleach", price: "₹200", description: "An oxygen-inspired facial care treatment." },
  { name: "Gold Bleach", category: "Bleach", price: "₹250", description: "A luxury gold facial bleach treatment." },
  { name: "Diamond Bleach", category: "Bleach", price: "₹300", description: "An ultra-premium diamond skincare treatment." },
];

const priceMenu: { title: Exclude<Category, "All">; items: { name: string; price: string }[] }[] = [
  { title: "Shaving", items: [{ name: "Denim", price: "₹40" }, { name: "Dettol", price: "₹40" }, { name: "Foam", price: "₹50" }, { name: "Gillette Foam", price: "₹60" }] },
  { title: "Hair Cutting", items: [{ name: "Round Hair", price: "₹30" }, { name: "Children's Haircut", price: "₹40" }, { name: "Haircut", price: "₹50" }, { name: "Fashion Haircut", price: "₹60" }] },
  { title: "Massage", items: [{ name: "Scrub", price: "₹80" }, { name: "Rose Massage", price: "₹150" }, { name: "Papaya", price: "₹150" }, { name: "Gold", price: "₹200" }, { name: "Diamond", price: "₹250" }] },
  { title: "Facial Kit", items: [{ name: "Real Aroma Kit", price: "₹800" }, { name: "Gold Facial Kit", price: "₹1,000" }, { name: "Diamond Facial Kit", price: "₹1,200" }, { name: "Shahnaz Kit", price: "₹2,500" }] },
  { title: "Bleach", items: [{ name: "Charcoal Mask", price: "₹150" }, { name: "Olivia", price: "₹150" }, { name: "Oxy Life", price: "₹200" }, { name: "Gold", price: "₹250" }, { name: "Diamond", price: "₹300" }] },
];

const categoryImage: Record<Exclude<Category, "All">, string> = {
  "Hair Cutting": "/manus-storage/ass-haircut_42688d53.jpg",
  Shaving: "/manus-storage/ass-shave_4d11c588.jpg",
  Massage: "/manus-storage/ass-treatment_cf8405a2.jpg",
  "Facial Kit": "/manus-storage/ass-space_7f17308e.jpg",
  Bleach: "/manus-storage/ass-hero_5b1acfd5.jpg",
};

const galleryItems = [
  { label: "Barber Area", image: "/manus-storage/ass-gallery-interior_1e98df09.jpg", alt: "Dark barber salon interior with leather chairs" },
  { label: "Interior", image: "/manus-storage/ass-space_7f17308e.jpg", alt: "Premium barber chair and dark salon interior" },
  { label: "Details", image: "/manus-storage/ass-gallery-chair_e51c25b5.jpg", alt: "Vintage barber chair in a salon setting" },
];

function scrollTo(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

export default function Home() {
  const [entryVisible, setEntryVisible] = useState(true);
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<Category>("All");
  const [lightbox, setLightbox] = useState<(typeof galleryItems)[number] | null>(null);
  const [formStatus, setFormStatus] = useState("");
  const approvedFeedback = trpc.feedback.publicList.useQuery();

  useEffect(() => {
    const timer = window.setTimeout(() => setEntryVisible(false), 4700);
    const onScroll = () => setScrolled(window.scrollY > 32);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen || lightbox ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [menuOpen, lightbox]);

  const visibleCategories = (priceMenu.map((group) => group.title)).filter(
    (category) => activeCategory === "All" || category === activeCategory,
  );

  const navigate = (id: string) => {
    setMenuOpen(false);
    window.setTimeout(() => scrollTo(id), 40);
  };

  const handleForm = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormStatus(`Thank you. Please call ${PHONE} to confirm your appointment.`);
    event.currentTarget.reset();
  };

  return (
    <div className={`site-shell ${entryVisible ? "is-entry" : ""}`}>
      <div className={`entry-screen ${entryVisible ? "" : "leaving"}`} aria-hidden={!entryVisible}>
        <div className="entry-ambient" />
        <div className="entry-light" />
        <div className="entry-content">
          <div className="scissor-stage" aria-hidden="true">
            <span className="blade blade-one" /><span className="blade blade-two" />
            <span className="scissor-ring" /><span className="scissor-ring second" /><span className="scissor-pivot" />
          </div>
          <p className="entry-kicker">A.S.S</p>
          <div className="entry-title">Gents Fashion<br />Parlour</div>
          <p className="entry-subtitle">KHUTAHA • GHORAWAL • SONBHADRA</p>
        </div>
        <button className="entry-skip" onClick={() => setEntryVisible(false)}>Skip intro</button>
      </div>

      <header className={`nav ${scrolled ? "is-scrolled" : ""}`}>
        <a className="brand" href="#home" onClick={(event) => { event.preventDefault(); navigate("home"); }} aria-label="A.S.S Gents Fashion Parlour home">
          <img className="brand-mark" src="/manus-storage/ass-scissors-mark_6f5aff37.png" alt="" />
          <span><strong>A.S.S</strong><span>GENTS FASHION PARLOUR</span></span>
        </a>
        <nav className="nav-links" aria-label="Primary navigation">
          <a href="#home">HOME</a><a href="#about">ABOUT</a><a href="#services">SERVICES</a><a href="#home-service">HOME SERVICE</a><a href="#prices">PRICES</a><a href="#gallery">GALLERY</a><a href="#contact">CONTACT</a>
        </nav>
        <a className="nav-call desktop-only" href={PHONE_LINK}><Phone size={13} /> CALL NOW</a>
        <button className="nav-toggle" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button>
      </header>

      <nav className={`mobile-menu ${menuOpen ? "open" : ""}`} aria-label="Mobile navigation">
        {[['HOME', 'home'], ['ABOUT', 'about'], ['SERVICES', 'services'], ['HOME SERVICE', 'home-service'], ['PRICES', 'prices'], ['GALLERY', 'gallery'], ['CONTACT', 'contact']].map(([label, id]) => (
          <a key={id} href={`#${id}`} onClick={(event) => { event.preventDefault(); navigate(id); }}>{label}</a>
        ))}
        <a className="mobile-call" href={PHONE_LINK}>{PHONE}</a>
      </nav>

      <main>
        <section className="hero" id="home">
          <div className="hero-media" /><div className="hero-wash" />
          <div className="hero-copy">
            <span className="eyebrow">Men&apos;s Grooming • Style • Care</span>
            <h1>YOUR STYLE.<br /><i>YOUR</i> IDENTITY.</h1>
            <p className="hero-text">Professional men&apos;s grooming and styling in Khutaha, Ghorawal, Sonbhadra.</p>
            <div className="hero-actions">
              <button className="button-primary" onClick={() => scrollTo("services")}>Explore services <ArrowRight size={15} /></button>
              <a className="button-home" href="/home-service"><House size={15} /> Book home service</a>
              <a className="button-ghost" href={PHONE_LINK}><Phone size={14} /> Call now</a>
            </div>
          </div>
          <div className="hero-detail"><span>Style, care and a fresh perspective.</span></div>
          <div className="scroll-cue">Scroll to explore</div>
        </section>

        <section className="section intro" id="about">
          <div className="intro-visual"><img src="/manus-storage/ass-space_7f17308e.jpg" alt="Luxury dark barber chair and salon interior" /><span className="image-note">The studio</span></div>
          <div className="intro-copy">
            <span className="eyebrow">The A.S.S approach</span>
            <h2>LOOK SHARP.<br /><span className="bronze">FEEL CONFIDENT.</span></h2>
            <p>A.S.S Gents Fashion Parlour provides men&apos;s grooming services including haircuts, shaving, massage, facial care and bleach treatments.</p>
            <ul className="feature-list"><li>PROFESSIONAL GROOMING</li><li>MEN&apos;S HAIR STYLING</li><li>FACIAL &amp; SKIN CARE</li><li>MODERN GROOMING EXPERIENCE</li></ul>
            <div className="scissors-badge"><img src="/manus-storage/ass-scissors-mark_6f5aff37.png" alt="" /> Defined by detail</div>
          </div>
        </section>

        <section className="section services" id="services">
          <div className="section-head"><span className="eyebrow">Crafted around you</span><h2>THE SERVICE EDIT.</h2><p>Choose from the supplied grooming services below. Every price is displayed clearly and exactly.</p><img className="section-mark" src="/manus-storage/ass-scissors-mark_6f5aff37.png" alt="" /></div>
          <div className="filter-row" aria-label="Filter services">
            {(["All", "Shaving", "Hair Cutting", "Massage", "Facial Kit", "Bleach"] as Category[]).map((category) => <button key={category} className={`filter ${activeCategory === category ? "active" : ""}`} onClick={() => setActiveCategory(category)}>{category}</button>)}
          </div>
          <div className="service-edit">
            {visibleCategories.map((category, index) => {
              const categoryServices = services.filter((service) => service.category === category);
              return <article className={`service-chapter chapter-${index + 1}`} key={category}>
                <div className="chapter-visual" style={{ backgroundImage: `url(${categoryImage[category]})` }}><div className="chapter-visual-shade" /><span>0{index + 1}</span><h3>{category}</h3><p>Made for detail.</p></div>
                <div className="chapter-list">
                  {categoryServices.map((service, rowIndex) => <div className="chapter-line" key={service.name}><span className="line-no">0{rowIndex + 1}</span><div><h4>{service.name}</h4><p>{service.description}</p></div><strong>{service.price}</strong><a href={PHONE_LINK} aria-label={`Call about ${service.name}`}>Call <ArrowRight size={12} /></a></div>)}
                </div>
              </article>;
            })}
          </div>
          <div className="services-note">Choose a category to focus the edit · Call the salon to confirm your service</div>
          <div className="service-home-prompt"><div><span className="eyebrow">At-home option</span><strong>Prefer your own space?</strong><p>Request a haircut, shaving, fashion haircut, facial or massage service at home. Your location and any home-service charge are confirmed directly by the salon.</p></div><a className="button-ghost" href="/home-service">Book home service <ArrowRight size={14} /></a></div>
        </section>

        <section className="section home-service" id="home-service">
          <div className="home-service-media" /><div className="home-service-wash" />
          <div className="home-service-copy"><span className="eyebrow">A.S.S Home Service</span><div className="home-service-symbol"><Scissors size={18} /><span /> <House size={18} /></div><h2>YOUR GROOMING.<br /><span>YOUR HOME.</span></h2><p>Enjoy professional men&apos;s grooming services from the comfort of your home. Choose a suitable service, share your full address, and the salon will confirm availability directly.</p><div className="home-service-cards"><div><CalendarDays size={17} /><strong>Your preferred time</strong><small>Requested time confirmed by salon</small></div><div><MapPin size={17} /><strong>Your complete address</strong><small>Availability depends on location</small></div></div><div className="hero-actions"><a className="button-primary" href="/home-service">Book home service <ArrowRight size={15} /></a><a className="button-ghost" href={PHONE_LINK}><Phone size={14} /> Ask the salon</a></div></div>
        </section>

        <section className="section prices" id="prices">
          <div className="section-head"><span className="eyebrow">No ambiguity</span><h2>OUR PRICE MENU.</h2><p>An honest, straightforward service ledger for your next visit.</p><img className="section-mark light-mark" src="/manus-storage/ass-scissors-mark_6f5aff37.png" alt="" /></div>
          <div className="price-ledger">
            {priceMenu.map((group) => <div className="price-column" key={group.title}><h3>{group.title}</h3>{group.items.map((item) => <div className="price-item" key={item.name}><span>{item.name}</span><b>{item.price}</b></div>)}</div>)}
          </div>
          <div className="price-cta"><span>Not sure where to start? Speak with the salon directly for help choosing a service.</span><a className="button-primary" href={PHONE_LINK}>Call {PHONE} <Phone size={14} /></a></div>
        </section>

        <section className="section space" id="gallery">
          <div className="section-head"><span className="eyebrow">Our space</span><h2>STEP INTO THE EXPERIENCE.</h2><p>An atmosphere shaped by classic barber details, contemporary grooming and a focus on the chair.</p></div>
          <div className="gallery-grid">
            {galleryItems.map((item) => <button className="gallery-item" key={item.label} onClick={() => setLightbox(item)} aria-label={`View ${item.label} image`}><img src={item.image} alt={item.alt} /><span className="gallery-caption"><span>{item.label}</span><em>↗</em></span></button>)}
            <div className="gallery-item gallery-metal-tile"><div>Signature tool</div><img src="/manus-storage/ass-scissors-mark_6f5aff37.png" alt="Metallic barber scissors emblem" /></div>
          </div>
        </section>

        <section className="section experience">
          <div className="section-head"><span className="eyebrow">Why A.S.S</span><h2>THE A.S.S EXPERIENCE.</h2><p>Everything is organized around the men&apos;s grooming services, price clarity and a clean, comfortable salon setting described in the supplied information.</p></div>
          <div className="experience-list"><div className="experience-row"><span>01</span>Professional grooming</div><div className="experience-row"><span>02</span>Modern hair styling</div><div className="experience-row"><span>03</span>Men&apos;s grooming services</div><div className="experience-row"><span>04</span>Clean &amp; comfortable space</div><div className="experience-row"><span>05</span>Clear pricing</div></div>
        </section>

        <section className="section feedback-preview" id="feedback">
          <div className="section-head"><span className="eyebrow">Customer feedback</span><h2>YOUR EXPERIENCE,<br /><span className="bronze">IN YOUR WORDS.</span></h2><p>Every public comment here is an approved customer submission. Nothing is prewritten or added by the salon.</p><img className="section-mark" src="/manus-storage/ass-scissors-mark_6f5aff37.png" alt="" /></div>
          {approvedFeedback.isLoading ? <p className="feedback-state">Loading approved customer feedback…</p> : approvedFeedback.data?.length ? <div className="feedback-columns">{approvedFeedback.data.slice(0, 3).map((feedback) => <article className="feedback-note" key={feedback.id}><div className="feedback-note-top"><span className="rating-stars" aria-label={`${feedback.rating} out of 5 stars`}>{Array.from({ length: 5 }, (_, index) => <Star key={index} size={13} fill={index < feedback.rating ? "currentColor" : "none"} />)}</span>{feedback.serviceName && <small>{feedback.serviceName}</small>}</div><blockquote>“{feedback.message}”</blockquote><footer>{feedback.customerName} <span>·</span> customer submission</footer></article>)}</div> : <div className="feedback-empty"><MessageSquareHeart size={24} /><div><strong>Be the first to share genuine feedback.</strong><p>Customer ratings and comments will appear here only after the salon reviews and approves them.</p></div></div>}
          <div className="feedback-cta"><span>Visited A.S.S Gents Fashion Parlour?</span><a className="button-primary" href="/feedback">Rate your experience <ArrowRight size={14} /></a></div>
        </section>

        <section className="section location">
          <div className="location-wrap"><div className="location-copy"><span className="eyebrow">Find us locally</span><h2>VISIT A.S.S GENTS FASHION PARLOUR.</h2><address className="location-address">Khutaha,<br />Ghorawal,<br />Sonbhadra,<br />Uttar Pradesh, India</address><a className="location-phone" href={PHONE_LINK}><Phone size={17} />{PHONE}</a><div className="location-actions"><a className="button-primary" href={PHONE_LINK}>Call now</a><a className="button-ghost" href={DIRECTIONS} target="_blank" rel="noreferrer"><MapPin size={15} /> Get directions</a></div></div><div className="location-map"><div className="map-label"><small>KHUTAHA · GHORAWAL</small>Your next grooming appointment begins here.</div></div></div>
        </section>

        <section className="section contact" id="contact">
          <div><span className="eyebrow">Start with a call</span><h2>READY FOR A FRESH LOOK?</h2><p>Your next style starts here.</p><a className="contact-phone" href={PHONE_LINK}><Phone size={18} />{PHONE}</a></div>
          <form className="contact-form" onSubmit={handleForm}><div className="field"><label htmlFor="name">Name</label><input id="name" name="name" autoComplete="name" required /></div><div className="field"><label htmlFor="phone">Phone</label><input id="phone" name="phone" inputMode="tel" autoComplete="tel" required /></div><div className="field"><label htmlFor="message">Message</label><textarea id="message" name="message" required /></div><button className="button-primary" type="submit">Send message <Send size={14} /></button>{formStatus && <p className="form-status" role="status">{formStatus}</p>}</form>
        </section>

        <section className="final-cta"><div className="final-cta-content"><span className="eyebrow">A.S.S Gents Fashion Parlour</span><h2>YOUR NEXT LOOK STARTS HERE.</h2><p>Khutaha · Ghorawal · Sonbhadra</p><div className="hero-actions"><a className="button-primary" href={PHONE_LINK}>Call now <Phone size={14} /></a><button className="button-ghost" onClick={() => scrollTo("services")}>View services <Scissors size={14} /></button></div></div></section>
      </main>

      <footer className="footer"><div className="footer-brand"><img src="/manus-storage/ass-scissors-mark_6f5aff37.png" alt="" />A.S.S<small>GENTS FASHION PARLOUR · MEN&apos;S GROOMING · KHUTAHA</small></div><address>Khutaha, Ghorawal, Sonbhadra,<br />Uttar Pradesh, India<br /><a href={PHONE_LINK}>{PHONE}</a></address><nav className="footer-nav" aria-label="Footer navigation"><a href="#home">HOME</a><a href="#about">ABOUT</a><a href="#services">SERVICES</a><a href="#home-service">HOME SERVICE</a><a href="#feedback">FEEDBACK</a><a href="#prices">PRICES</a><a href="#gallery">GALLERY</a><a href="#contact">CONTACT</a></nav></footer>
      <nav className="mobile-bar" aria-label="Quick actions"><a href={PHONE_LINK}><Phone />Call</a><a href="#services"><Scissors />Services</a><a href="/home-service"><House />Home service</a><a href={DIRECTIONS} target="_blank" rel="noreferrer"><MapPin />Directions</a></nav>

      {lightbox && <div className="lightbox" role="dialog" aria-modal="true" aria-label={`${lightbox.label} image preview`} onClick={() => setLightbox(null)}><figure onClick={(event) => event.stopPropagation()}><button onClick={() => setLightbox(null)} aria-label="Close image preview"><X /></button><img src={lightbox.image} alt={lightbox.alt} /><figcaption>{lightbox.label}</figcaption></figure></div>}
    </div>
  );
}
