/**
 * Noir Atelier booking flow: a separate, focused Home Service request wizard
 * with Cinder Bronze progress cues and explicit salon-confirmation language.
 * It intentionally collects an address before a request can be submitted.
 */
import { ArrowLeft, ArrowRight, CalendarDays, Check, Clock3, House, MapPin, Phone, Scissors, Send } from "lucide-react";
import { FormEvent, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { HOME_SERVICE_AVAILABILITY_NOTICE, HOME_SERVICE_PRICE_NOTICE, type HomeServiceCatalogItem } from "@shared/homeService";
import { trpc } from "@/lib/trpc";

const PHONE_LINK = "tel:+919305968252";
const preferredTimes = ["10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"];
const steps = ["Service", "Date", "Time", "Details", "Review"];

type BookingState = {
  serviceId: string;
  requestedDate: string;
  requestedTime: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  specialInstructions: string;
};

function todayString() {
  return new Date().toISOString().slice(0, 10);
}

export default function HomeServiceBooking() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<BookingState>({ serviceId: "", requestedDate: todayString(), requestedTime: "", customerName: "", customerPhone: "", customerAddress: "", specialInstructions: "" });
  const [confirmation, setConfirmation] = useState<{ bookingId: string; ownerAlertDelivered: boolean } | null>(null);
  const catalog = trpc.homeService.catalog.useQuery();
  const requestMutation = trpc.homeService.createRequest.useMutation({
    onSuccess: (result) => setConfirmation({ bookingId: result.request.bookingId ?? "HOME-ASS", ownerAlertDelivered: result.ownerAlertDelivered }),
  });

  const selectedService = useMemo(() => catalog.data?.find((service) => service.id === form.serviceId), [catalog.data, form.serviceId]);
  const groupedServices = useMemo(() => {
    const groups = new Map<string, HomeServiceCatalogItem[]>();
    (catalog.data ?? []).forEach((service) => groups.set(service.category, [...(groups.get(service.category) ?? []), service]));
    return Array.from(groups.entries());
  }, [catalog.data]);

  const update = (key: keyof BookingState, value: string) => setForm((previous) => ({ ...previous, [key]: value }));
  const canNext = step === 0 ? Boolean(form.serviceId) : step === 1 ? Boolean(form.requestedDate) : step === 2 ? Boolean(form.requestedTime) : step === 3 ? Boolean(form.customerName.trim() && form.customerPhone.trim() && form.customerAddress.trim().length >= 15) : true;

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!selectedService) return;
    requestMutation.mutate(form);
  };

  if (confirmation) {
    return <main className="booking-page"><header className="booking-nav"><button onClick={() => setLocation("/")}><ArrowLeft size={16} /> Back to A.S.S</button><a href={PHONE_LINK}><Phone size={15} /> +91 93059 68252</a></header><section className="booking-confirmation"><div className="confirmation-mark"><Check /></div><span className="eyebrow">Request received</span><h1>HOME SERVICE<br /><em>REQUEST RECEIVED.</em></h1><p>Your request has been saved with the reference below. Home-service availability, preferred time, and any visit charge will be confirmed by the salon.</p><div className="booking-id">{confirmation.bookingId}</div><div className="confirmation-detail"><strong>What happens next</strong><span>The salon will review your selected service, address, and preferred time before confirming the request.</span></div><div className="booking-actions"><a className="button-primary" href={PHONE_LINK}><Phone size={14} /> Call the salon</a><button className="button-ghost" onClick={() => { setConfirmation(null); setStep(0); setForm({ serviceId: "", requestedDate: todayString(), requestedTime: "", customerName: "", customerPhone: "", customerAddress: "", specialInstructions: "" }); }}>Request another service</button></div></section></main>;
  }

  return <main className="booking-page"><header className="booking-nav"><button onClick={() => setLocation("/")}><ArrowLeft size={16} /> Back to A.S.S</button><a href={PHONE_LINK}><Phone size={15} /> +91 93059 68252</a></header><div className="booking-layout"><aside className="booking-aside"><div><div className="booking-wordmark"><img src="/manus-storage/ass-scissors-mark_6f5aff37.png" alt="" /><span><strong>A.S.S</strong><small>GENTS FASHION PARLOUR</small></span></div><span className="eyebrow">A.S.S Home Service</span><div className="booking-symbol"><Scissors size={18} /><span /> <House size={18} /></div><h1>YOUR GROOMING.<br /><em>YOUR HOME.</em></h1><p>Professional grooming, brought to your doorstep. Send a request, then let the salon confirm your location and preferred time.</p></div><div className="booking-notices"><p><MapPin size={15} />{HOME_SERVICE_AVAILABILITY_NOTICE}</p><p><House size={15} />{HOME_SERVICE_PRICE_NOTICE}</p></div></aside><section className="booking-panel"><div className="booking-panel-head"><span className="eyebrow">Request home service</span><h2>BOOK YOUR VISIT.</h2><p>Step {step + 1} of {steps.length} · {steps[step]}</p></div><div className="booking-progress">{steps.map((label, index) => <div className={index <= step ? "active" : ""} key={label}><span>{index < step ? <Check size={12} /> : index + 1}</span><small>{label}</small></div>)}</div><form onSubmit={submit}>
    {step === 0 && <div className="booking-step"><h3>Choose a service</h3><p>These are the existing salon services suitable for a Home Service request.</p>{catalog.isLoading && <div className="booking-loader">Loading available services…</div>}{groupedServices.map(([category, services]) => <div className="service-choice-group" key={category}><span>{category}</span><div>{services.map((service) => <button type="button" className={form.serviceId === service.id ? "selected" : ""} onClick={() => update("serviceId", service.id)} key={service.id}><strong>{service.name}</strong><b>₹{service.basePrice}</b><small>Base salon price</small></button>)}</div></div>)}</div>}
    {step === 1 && <div className="booking-step"><h3>Choose a preferred date</h3><p>The salon will confirm the final appointment after reviewing your request.</p><label className="booking-field"><span><CalendarDays size={16} /> Requested date</span><input type="date" min={todayString()} value={form.requestedDate} onChange={(event) => update("requestedDate", event.target.value)} required /></label></div>}
    {step === 2 && <div className="booking-step"><h3>Choose a preferred time</h3><p>Available time is confirmed by the salon. Select the time that suits you best.</p><div className="time-grid">{preferredTimes.map((time) => <button type="button" className={form.requestedTime === time ? "selected" : ""} onClick={() => update("requestedTime", time)} key={time}><Clock3 size={14} />{time}</button>)}</div></div>}
    {step === 3 && <div className="booking-step"><h3>Where should we come to you?</h3><p>A complete address is required so the salon can confirm Home Service availability.</p><div className="booking-fields"><label className="booking-field"><span>Name</span><input value={form.customerName} onChange={(event) => update("customerName", event.target.value)} autoComplete="name" required /></label><label className="booking-field"><span>Mobile number</span><input value={form.customerPhone} onChange={(event) => update("customerPhone", event.target.value)} inputMode="tel" autoComplete="tel" required /></label><label className="booking-field full"><span>Complete home address</span><textarea value={form.customerAddress} onChange={(event) => update("customerAddress", event.target.value)} autoComplete="street-address" minLength={15} required /></label><label className="booking-field full"><span>Special instructions <small>(optional)</small></span><textarea value={form.specialInstructions} onChange={(event) => update("specialInstructions", event.target.value)} /></label></div></div>}
    {step === 4 && <div className="booking-step"><h3>Review your request</h3><p>Check the details below before asking the salon to review your Home Service request.</p><div className="request-summary"><div><span>Home Service</span><b>{selectedService?.name}</b></div><div><span>Requested date</span><b>{form.requestedDate}</b></div><div><span>Preferred time</span><b>{form.requestedTime}</b></div><div><span>Customer</span><b>{form.customerName}</b></div><div><span>Mobile</span><b>{form.customerPhone}</b></div><div className="summary-address"><span>Address</span><b>{form.customerAddress}</b></div><div><span>Service price</span><b>{selectedService ? `₹${selectedService.basePrice}` : "To be confirmed"}</b></div><div><span>Home visit charge</span><b>To be confirmed</b></div><div className="summary-total"><span>Total</span><b>To be confirmed</b></div></div></div>}
    {requestMutation.error && <p className="booking-error" role="alert">{requestMutation.error.message}</p>}
    <div className="booking-controls">{step > 0 ? <button type="button" className="booking-back" onClick={() => setStep((previous) => previous - 1)}><ArrowLeft size={15} /> Back</button> : <a className="booking-back" href={PHONE_LINK}><Phone size={15} /> Book at salon</a>}{step < steps.length - 1 ? <button type="button" className="button-primary" onClick={() => canNext && setStep((previous) => previous + 1)} disabled={!canNext}>Continue <ArrowRight size={15} /></button> : <button className="button-primary" type="submit" disabled={requestMutation.isPending}>{requestMutation.isPending ? "Sending request…" : <>Request home service <Send size={15} /></>}</button>}</div>
  </form></section></div></main>;
}
