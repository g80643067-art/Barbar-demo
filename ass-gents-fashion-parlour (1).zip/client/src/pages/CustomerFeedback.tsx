/** Public, genuine-customer feedback submission. It does not show fabricated
 * praise: every submission is private until an administrator approves it. */
import { ArrowLeft, Check, MessageSquareHeart, Phone, Star } from "lucide-react";
import { FormEvent, useState } from "react";
import { useLocation } from "wouter";
import { CUSTOMER_RATINGS, ratingLabel } from "@shared/customerFeedback";
import { trpc } from "@/lib/trpc";

const PHONE_LINK = "tel:+919305968252";

export default function CustomerFeedback() {
  const [, setLocation] = useLocation();
  const [rating, setRating] = useState<number>(0);
  const [customerName, setCustomerName] = useState("");
  const [serviceName, setServiceName] = useState("");
  const [message, setMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const submit = trpc.feedback.submit.useMutation({ onSuccess: () => setSubmitted(true) });

  const submitFeedback = (event: FormEvent) => {
    event.preventDefault();
    if (!rating) return;
    submit.mutate({ rating, customerName, serviceName: serviceName || undefined, message });
  };

  if (submitted) return <main className="feedback-page"><header className="feedback-nav"><button onClick={() => setLocation("/")}><ArrowLeft size={16} /> Back to A.S.S</button><a href={PHONE_LINK}><Phone size={15} /> +91 93059 68252</a></header><section className="feedback-success"><div><Check /></div><span className="eyebrow">Feedback received</span><h1>THANK YOU FOR<br /><em>YOUR WORDS.</em></h1><p>Your customer feedback has been received. It will only appear publicly after the salon reviews and approves this genuine submission.</p><button className="button-primary" onClick={() => setLocation("/")}>Return to the salon site</button></section></main>;

  return <main className="feedback-page"><header className="feedback-nav"><button onClick={() => setLocation("/")}><ArrowLeft size={16} /> Back to A.S.S</button><a href={PHONE_LINK}><Phone size={15} /> +91 93059 68252</a></header><section className="feedback-form-wrap"><aside className="feedback-form-intro"><div className="feedback-brand-mark"><img src="/manus-storage/ass-scissors-mark_6f5aff37.png" alt="" /><span><strong>A.S.S</strong><small>GENTS FASHION PARLOUR</small></span></div><span className="eyebrow">Genuine customer feedback</span><MessageSquareHeart size={28} /><h1>HOW WAS<br /><em>YOUR VISIT?</em></h1><p>Tell the salon about your genuine experience. Your comments stay private until the salon reviews them; no feedback is published automatically.</p></aside><form className="feedback-form" onSubmit={submitFeedback}><div className="feedback-form-head"><span className="eyebrow">Share your experience</span><h2>LEAVE FEEDBACK.</h2><p>Your rating helps the salon understand your visit.</p></div><fieldset className="rating-field"><legend>Your rating</legend><div>{CUSTOMER_RATINGS.map((value) => <button type="button" className={rating >= value ? "selected" : ""} onClick={() => setRating(value)} aria-label={`${value} star${value === 1 ? "" : "s"}`} key={value}><Star fill="currentColor" /></button>)}</div>{rating ? <small>{rating} / 5 · {ratingLabel(rating)}</small> : <small>Select a rating from 1 to 5</small>}</fieldset><label><span>Your name</span><input value={customerName} onChange={(event) => setCustomerName(event.target.value)} autoComplete="name" required /></label><label><span>Service received <small>(optional)</small></span><input value={serviceName} onChange={(event) => setServiceName(event.target.value)} placeholder="For example: Haircut" /></label><label><span>Your feedback</span><textarea value={message} onChange={(event) => setMessage(event.target.value)} placeholder="Share your experience in your own words." minLength={12} required /></label><p className="feedback-privacy">Only genuine feedback is accepted. Your submission is private until the salon reviews it.</p>{submit.error && <p className="feedback-error" role="alert">{submit.error.message}</p>}<button className="button-primary" type="submit" disabled={!rating || submit.isPending}>{submit.isPending ? "Sending feedback…" : "Submit genuine feedback"}</button></form></section></main>;
}
