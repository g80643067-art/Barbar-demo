/**
 * Noir Atelier visual system: an obsidian, editorial shell with Cinder Bronze
 * accents. The application stays intentionally dark to preserve the cinematic
 * transition from entry sequence to salon content.
 */
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import HomeServiceAdmin from "./pages/HomeServiceAdmin";
import HomeServiceBooking from "./pages/HomeServiceBooking";
import CustomerFeedback from "./pages/CustomerFeedback";
import CustomerFeedbackAdmin from "./pages/CustomerFeedbackAdmin";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/home-service" component={HomeServiceBooking} />
      <Route path="/admin/home-service" component={HomeServiceAdmin} />
      <Route path="/feedback" component={CustomerFeedback} />
      <Route path="/admin/feedback" component={CustomerFeedbackAdmin} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
